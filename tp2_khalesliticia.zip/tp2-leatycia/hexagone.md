# TP 2 · Hexagone de ShopLite (parcours Data)

Leatycia

## Étape 1 · Le même cas d'utilisation par trois portes

| Porte | Résultat obtenu |
|---|---|
| Ligne de commande | `node seance2-architecture/hexagonal/cli.js C-42 CLAVIER:2 SOURIS:1` → `[e-mail simulé] Commande CMD-0001 confirmée pour C-42 : 117 €`, puis `Commande créée : {"id":"CMD-0001", …, "total":117, …}` |
| HTTP : commande valide | `POST /orders` (CLAVIER ×2, SOURIS ×1) → **201 Created**, `id: "CMD-0001"`, `total: 117`, `createdAt` renseigné |
| HTTP : relecture de la commande | `GET /orders/CMD-0001` → **200 OK**, exactement la même commande |
| HTTP : produit inconnu | `POST /orders` (TELE) → **400 Bad Request**, `{ "error": "Produit inconnu : TELE" }` |
| HTTP : commande vide | `POST /orders` (`items: []`) → **400 Bad Request**, `{ "error": "Une commande doit contenir au moins une ligne" }` |
| Tests : combien ? serveur nécessaire ? | `node --test seance2-architecture/hexagonal/PlaceOrder.test.js` → **3 tests, 3 pass, 0 fail**. Aucun serveur ni base : les ports sont simulés. |

**Ce qui est identique :** les trois portes appellent le même cas d'utilisation `PlaceOrder.handle()`, qui applique les mêmes règles du domaine `Order` (même total de 117 €, mêmes messages d'erreur).
**Ce qui change :** seulement la façon d'entrer et de sortir : arguments `SKU:qté` et console pour la CLI, JSON et codes HTTP (201 / 400 / 404) pour l'API, appels directs et `assert` pour les tests.
**Conséquence :** on peut ajouter une quatrième porte (file de messages, interface web) sans toucher au cœur.

## Étape 2 · L'hexagone

```mermaid
flowchart LR
  subgraph Primaires["Adaptateurs primaires (pilotent)"]
    HTTP[adapters/primary/httpServer.js]
    CLI[cli.js]
    TEST[PlaceOrder.test.js]
  end

  subgraph Coeur["Cœur (application + domaine)"]
    UC[application/PlaceOrder.js<br/>port entrant : handle]
    D[domain/Order.js]
  end

  subgraph Secondaires["Adaptateurs secondaires (pilotés)"]
    REPO[InMemoryOrderRepository.js]
    CAT[StaticCatalog.js]
    NOTIF[ConsoleNotifier.js]
    TIME["clock / ids<br/>(définis dans container.js)"]
  end

  subgraph Composition["Composition root (hors hexagone)"]
    CONT[container.js]
    MAIN[main.js]
  end

  HTTP --> UC
  CLI --> UC
  TEST --> UC
  UC --> D
  UC -- port OrderRepository --> REPO
  UC -- port Catalog --> CAT
  UC -- port Notifier --> NOTIF
  UC -- ports Clock / Ids --> TIME

  MAIN --> CONT
  MAIN -. démarre .-> HTTP
  CLI -. buildApp .-> CONT
  CONT -. crée et injecte .-> UC
  CONT -. crée .-> REPO
  CONT -. crée .-> CAT
  CONT -. crée .-> NOTIF
```

`requests.http` n'est pas du code de l'application : c'est un client qui pilote l'adaptateur HTTP de l'extérieur.

**Où placer `container.js` ?** En dehors de l'hexagone, à côté des adaptateurs : c'est le seul endroit qui connaît à la fois le cœur et les adaptateurs concrets, car son rôle est de les créer et de les brancher sur les ports (`main.js` et `cli.js` l'utilisent).

**Règle de dépendance :** les dépendances pointent toujours vers le cœur ; `domain/` n'importe rien, `application/` n'importe que `domain/`, et seuls les adaptateurs et la composition root connaissent les technologies (vérifié par `npm run lint:archi`).
