# Note de spécialité DATA · Le contrat des données de la commande

Leatycia · fichiers lus : `domain/Order.js`, `adapters/secondary/InMemoryOrderRepository.js`, `container.js`

**1. Champs.** Stockés : `id`, `customerId`, `createdAt` et `lines` (chaque ligne : `sku`, `qty`, `unitPrice`). Calculé : `total` (getter, somme des `qty × unitPrice`), jamais stocké mais exposé par `toJSON()`.
*Vérifié :* `curl localhost:3000/orders/CMD-0001` → `total: 117` alors qu'aucun champ `total` n'est écrit dans le constructeur.

**2. Prix copié dans la ligne.** Si le prix du catalogue change demain, une commande passée garde le prix réellement payé : l'historique, le chiffre d'affaires et les statistiques restent justes et reproductibles. Sans cette copie, recalculer une ancienne commande donnerait un autre montant.
*Vérifié :* la réponse de `POST /orders` contient `"unitPrice": 49` dans chaque ligne.

**3. `findById` absent.** Renvoie `undefined` (`Map.get`). Ce n'est écrit nulle part : le contrat du port dans `PlaceOrder.js` dit seulement `findById(id)`. C'est l'adaptateur HTTP qui le traduit en 404.
*Vérifié :* `curl localhost:3000/orders/CMD-9999` → **404** `Commande introuvable`.

**4. Redémarrage et identifiants.** Les commandes sont perdues (une `Map` en mémoire). Les ids viennent d'un compteur `n` dans `buildApp()` (`CMD-0001`, `CMD-0002`…), remis à zéro au démarrage : après un redémarrage, **le même id `CMD-0001` est attribué à une autre commande**.
*Vérifié :* arrêt/relance du serveur → `GET /orders/CMD-0001` → **404** ; nouvelle commande de C-7 → `id: "CMD-0001"`. En base, ce serait un conflit de clé primaire ; il faudra une séquence ou un UUID.

**Autres constats utiles pour la base :**
- `node …/cli.js C-42 CLAVIER:1.5` est **accepté** (total 73,5 €) : le domaine vérifie `qty > 0` mais pas que la quantité est entière.
- `node …/cli.js C-42 CLAVIER:1 CLAVIER:1` donne **deux lignes avec le même `sku`** : `(order_id, sku)` ne peut pas être une clé.

**5. Schéma PostgreSQL proposé**

```sql
CREATE TABLE orders (
  id          VARCHAR(20)  PRIMARY KEY,          -- ou UUID, généré par une séquence
  customer_id VARCHAR(50)  NOT NULL,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE order_lines (
  order_id    VARCHAR(20)   NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  line_no     INTEGER       NOT NULL,
  sku         VARCHAR(50)   NOT NULL,
  qty         INTEGER       NOT NULL CHECK (qty > 0),
  unit_price  NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
  PRIMARY KEY (order_id, line_no)
);
```

Le `total` n'est pas stocké (calculé par `Order`, ou par `SUM(qty * unit_price)` en SQL). `NUMERIC` évite les erreurs d'arrondi des flottants sur les montants. La traduction objet `Order` ↔ lignes des tables se ferait dans un nouvel adaptateur secondaire `adapters/secondary/PostgresOrderRepository.js` ; seul `container.js` changerait pour l'utiliser, le domaine et le cas d'utilisation restent intacts.

**Règle d'architecture (étape 4).** Ajout de `import { buildApp } from '../container.js';` en tête de `hexagonal/domain/Order.js`, puis `npm run lint:archi` :

```
✗ Règle violée : le domaine dépend de l'extérieur :
   seance2-architecture/hexagonal/domain/Order.js  ->  ../container.js
```

Ligne retirée, `npm run lint:archi` → `✓ Règle de dépendance respectée`, fichier remis à l'identique.
