# ADR-0001 : Isoler le stockage derrière le port OrderRepository

- Date : 2026-10-21
- Statut : Accepté
- Décideurs : Leatycia

## Contexte

Les commandes de ShopLite sont stockées dans une `Map` en mémoire : elles disparaissent à
chaque redémarrage du serveur, et le compteur d'identifiants repart à `CMD-0001`, ce qui
réattribue un id déjà utilisé à une autre commande. Une base PostgreSQL est prévue, et les
équipes Data voudront exploiter l'historique (chiffre d'affaires, produits vendus).
Le format de stockage va donc changer, alors que les règles métier de `Order` doivent rester
les mêmes et que les tests doivent continuer à tourner sans base.

## Décision

Le cas d'utilisation n'accède aux données qu'à travers le port `OrderRepository`
(`save(order)`, `findById(id)` qui renvoie `null` si absent) ; chaque technologie de stockage
est un adaptateur secondaire (`InMemoryOrderRepository` aujourd'hui, `PostgresOrderRepository`
demain), choisi uniquement dans `container.js`.

## Conséquences

- (+) Passer à PostgreSQL revient à écrire un adaptateur et à changer une ligne de
  `container.js`, sans modifier `Order` ni `PlaceOrder`.
- (+) Les tests restent rapides et sans base grâce à l'adaptateur en mémoire.
- (+) La règle de dépendance est vérifiée par `npm run lint:archi` : en ajoutant
  `import { buildApp } from '../container.js'` dans `domain/Order.js`, on obtient
  « ✗ Règle violée : le domaine dépend de l'extérieur ». Elle empêche le métier de
  dépendre d'une technologie de stockage.
- (−) La traduction objet `Order` ↔ tables `orders` / `order_lines` est à écrire et à
  maintenir dans l'adaptateur, y compris la reconstruction d'une `Order` depuis la base.
- (−) Le contrat du port n'est écrit qu'en commentaire : aujourd'hui `findById` renvoie
  `undefined`, rien ne garantit que chaque adaptateur se comporte pareil ; il faudra des tests
  de contrat communs aux adaptateurs.
- (−) Les requêtes d'analyse (totaux par client, par mois) ne passent pas par le port :
  elles devront lire la base directement ou via un port de lecture dédié, ce qui ajoute une
  indirection.

## Alternatives considérées

- Appeler PostgreSQL directement depuis `PlaceOrder` (requêtes SQL dans le cas
  d'utilisation) : rejetée parce que le métier dépendrait de la base, les tests exigeraient
  une vraie base, et tout changement de schéma toucherait le cas d'utilisation.
- Utiliser un ORM dont les entités sont aussi les objets métier : rejetée parce que `Order`
  hériterait des contraintes de l'ORM (annotations, champs publics), ce qui casse
  l'encapsulation de `#lines` et la règle « aucun import dans `domain/` ».
